function [LL,t_nodes,T_nodes] = invert(niter,n_nodes,kineticsfiles,profilefiles,num_GridNodes,max_T,monotonic)
    nd = length(kineticsfiles);
    M = 0; % maximum apparent ager_
    SampleData = cell(nd);
    GridNode = cell(nd);
    eff238Conc = cell(nd);
    r_sphere = cell(nd);
    depth = cell(nd);
    mu = cell(nd);
    sigma = cell(nd);
    for i=1:nd,
        disp(strcat('Loading profile #',num2str(i),' ...'));
        [SampleData{i},GridNode{i},eff238Conc{i},r_sphere{i}] = kinetics(kineticsfiles{i},num_GridNodes);
        [depth{i},mu{i},sigma{i}] = profile(profilefiles{i});
        M = max([M,max(mu{i})]);
    end
    t_nodes = linspace(M,0,n_nodes)';   % initial guess for the time nodes
    n_walkers = n_nodes*5;
    T_nodes_i = initialise(t_nodes,max_T,n_walkers);  % initial guess for the temperature nodes
    loglik = @(Tn) getLL(Tn,t_nodes,nd,SampleData,GridNode,eff238Conc,depth,mu,sigma,r_sphere,num_GridNodes);
    logprior = @(Tn)(prior(Tn,max_T,monotonic));
    [T_nodes,logP] = gwmcmc(T_nodes_i,{logprior loglik},niter);
    %flatten the chain: analyze all the chains as one
    T_nodes = T_nodes(:,:);
    logP = logP(:,:);
    LL = logP(2,:);
end

function valid = prior(Tn,max_T,monotonic)
    n = length(Tn);
    valid = Tn(1)==max_T && Tn(end)==0;
    if (monotonic)
        for i = 2:n-1,
            valid = valid && Tn(i)>Tn(i+1);
        end
    else
        valid = valid && all(Tn(2:n-1)>0 & Tn(2:n-1)<max_T);
    end
end

% calculate the log-likelihood
function out = getLL(T_nodes,t_nodes,nd,SampleData,GridNode,eff238Conc,depth,mu,sigma,r_sphere,num_GridNodes)
    [t,T] = interpolate(t_nodes,T_nodes,32);
    out = 0;
    for j = 1:nd,
        Conc206_node = Function_UPbDiff(t,T,SampleData{j},GridNode{j},eff238Conc{j});
        out = out + misfit(Conc206_node,eff238Conc{j},depth{j},mu{j},sigma{j},r_sphere{j},num_GridNodes);
    end
end

function out = misfit(Conc206_node,eff238Conc,depth,mu,sigma,r_sphere,num_GridNodes)
    lyr238 = 1.55125e-10;
    Conc206_node_all(:,1) = single(Conc206_node);
    Age206_node_all(:,1)  = log((Conc206_node_all(:,1)./eff238Conc(:))+1)/lyr238;
    rx = linspace(0,r_sphere*10000,num_GridNodes)'; % radial distance in microns
    ry = Age206_node_all/1000000; % modelled ages
    rd = r_sphere*10000-rx; % radial depth
    mage = interp1(rd,ry,depth); % modelled age at the depth of the measurements
    out = - sum( log(sigma) + ((mage-mu).^2)./(2*sigma.^2) );
end

function out = initialise(t_nodes,max_T,n_walkers)
    n_nodes = length(t_nodes);
    out = [ones(1,n_walkers)*max_T;
           sort(rand(n_nodes-2,n_walkers)*max_T,1,'descend');
           zeros(1,n_walkers)];
end