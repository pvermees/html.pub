function[t,T] = interpolate(t_nodes,T_nodes,resolution)
    t = linspace(max(t_nodes),min(t_nodes),resolution)';
    T = pchip(t_nodes,T_nodes,t);
end