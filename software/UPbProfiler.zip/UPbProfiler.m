function varargout = UPbProfiler(varargin)
% UPBPROFILER MATLAB code for UPbProfiler.fig
%      UPBPROFILER, by itself, creates a new UPBPROFILER or raises the existing
%      singleton*.
%
%      H = UPBPROFILER returns the handle to a new UPBPROFILER or the handle to
%      the existing singleton*.
%
%      UPBPROFILER('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in UPBPROFILER.M with the given input arguments.
%
%      UPBPROFILER('Property','Value',...) creates a new UPBPROFILER or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before UPbProfiler_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to UPbProfiler_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help UPbProfiler

% Last Modified by GUIDE v2.5 09-Feb-2018 11:19:58

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @UPbProfiler_OpeningFcn, ...
                   'gui_OutputFcn',  @UPbProfiler_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before UPbProfiler is made visible.
function UPbProfiler_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to UPbProfiler (see VARARGIN)

% Choose default command line output for UPbProfiler
handles.output = hObject;
handles.nnodes = 5;
handles.Tmax = 825;
handles.niter = 20000;
handles.burnin = 20;
handles.monotonic = true;
handles.kfiles = {};
handles.pfiles = {};
handles.t_nodes = [];
handles.T_nodes = [];
handles.LL = [];
set(handles.nnodebox,'String',handles.nnodes);
set(handles.TmaxBox,'String',handles.Tmax);
set(handles.niterbox,'String',handles.niter);
set(handles.burninbox,'String',handles.burnin);
set(handles.monotonicradiobutton,'Value',handles.monotonic);
warning('off','MATLAB:gui:latexsup:UnableToInterpretTeXString');
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes UPbProfiler wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% --- Outputs from this function are returned to the command line.
function varargout = UPbProfiler_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Get default command line output from handles structure
varargout{1} = handles.t_nodes;
varargout{2} = handles.T_nodes;
varargout{3} = handles.LL;

function nnodebox_Callback(hObject, eventdata, handles)
% hObject    handle to nnodebox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of nnodebox as text
%        str2double(get(hObject,'String')) returns contents of nnodebox as a double


% --- Executes during object creation, after setting all properties.
function nnodebox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nnodebox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function TmaxBox_Callback(hObject, eventdata, handles)
% hObject    handle to TmaxBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of TmaxBox as text
%        str2double(get(hObject,'String')) returns contents of TmaxBox as a double

% --- Executes during object creation, after setting all properties.
function TmaxBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TmaxBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function niterbox_Callback(hObject, eventdata, handles)
% hObject    handle to niterbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of niterbox as text
%        str2double(get(hObject,'String')) returns contents of niterbox as a double

% --- Executes during object creation, after setting all properties.
function niterbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to niterbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in monotonicradiobutton.
function monotonicradiobutton_Callback(hObject, eventdata, handles)
% hObject    handle to monotonicradiobutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of monotonicradiobutton

function kfilebox_Callback(hObject, eventdata, handles)
% hObject    handle to kfilebox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of kfilebox as text
%        str2double(get(hObject,'String')) returns contents of kfilebox as a double

% --- Executes during object creation, after setting all properties.
function kfilebox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to kfilebox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function pfilebox_Callback(hObject, eventdata, handles)
% hObject    handle to pfilebox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pfilebox as text
%        str2double(get(hObject,'String')) returns contents of pfilebox as a double

% --- Executes during object creation, after setting all properties.
function pfilebox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pfilebox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in kbutton.
function kbutton_Callback(hObject, eventdata, handles)
% hObject    handle to kbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[FileName,PathName,FilterIndex] = uigetfile('*.xls','MultiSelect','on');
if (isa(FileName,'char'))
    handles.kfiles = cell(1);
    handles.kfiles{1} = strcat(PathName,FileName);
else
    nf = length(FileName);
    for i = 1:nf,
        handles.kfiles(i) = strcat(PathName,FileName(i));
    end
end
set(handles.kfilebox,'String',char(handles.kfiles));
guidata(hObject, handles);

% --- Executes on button press in pbutton.
function pbutton_Callback(hObject, eventdata, handles)
% hObject    handle to pbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[FileName,PathName,FilterIndex] = uigetfile('*.txt','MultiSelect','on');
if (isa(FileName,'char'))
    handles.pfiles = cell(1);
    handles.pfiles{1} = strcat(PathName,FileName);
else
    nf = length(FileName);
    for i = 1:nf,
        handles.pfiles(i) = strcat(PathName,FileName(i));
    end
end
set(handles.pfilebox,'String',char(handles.pfiles));
guidata(hObject, handles);

% --- Executes on button press in runbutton.
function runbutton_Callback(hObject, eventdata, handles)
% hObject    handle to runbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.niter = str2double(get(handles.niterbox,'String'));
handles.nnodes = str2double(get(handles.nnodebox,'String'));
handles.burnin = str2double(get(handles.burninbox,'String'));
handles.Tmax = str2double(get(handles.TmaxBox,'String'));
handles.monotonic = get(handles.monotonicradiobutton,'Value');
num_GridNodes = 512;
[handles.LL,handles.t_nodes,handles.T_nodes] = ...
    invert(handles.niter,handles.nnodes,handles.kfiles,handles.pfiles, ...
           num_GridNodes,handles.Tmax,handles.monotonic);
guidata(hObject, handles);
plotter(handles.LL,handles.t_nodes,handles.T_nodes,handles.burnin, ...
        handles.kfiles,handles.pfiles,num_GridNodes);

function burninbox_Callback(hObject, eventdata, handles)
% hObject    handle to burninbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of burninbox as text
%        str2double(get(hObject,'String')) returns contents of burninbox as a double

% --- Executes during object creation, after setting all properties.
function burninbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to burninbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
