function plotter(LL,t_nodes,T_nodes,burnin,kineticsfiles,profilefiles,num_GridNodes)

close all;

n  = length(LL);
b = round(length(LL)*burnin/100);
[ML,mi] = max(LL);
best_T = T_nodes(:,mi);

resolution = 32;

% plotting
% fig 1: LL with time
figure
disp('Plotting the Likelihood ...');
plot(1:length(LL)-1,LL(2:end),'-k',[b,b],[min(LL),ML],'-b');
xlabel('iteration'); ylabel('log-likelihood');

% fig 2: Tt paths shaded for LL
figure
disp('Plotting the t-T paths ...');
hold on;
s = linspace(0,1,100);
rgb1 = [0.230, 0.299, 0.754];
rgb2 = [0.706, 0.016, 0.150];
cmap = diverging_map(s,rgb1,rgb2);
t = linspace(max(t_nodes),min(t_nodes),resolution);
T = zeros(resolution,n-b);
mL = min(LL(b:n));
for i=1:n-b,
    T(:,i) = pchip(t_nodes,T_nodes(:,i+b-1),t);
    ci = floor(99*(LL(i+b-1)-mL)/(ML-mL))+1; % colour index
    plot(t, T(:,i), 'Color', [cmap(ci,1) cmap(ci,2) cmap(ci,3)]);
end
colormap(cmap);
c=colorbar;
caxis([min(LL) max(LL)]);
set(get(c,'ylabel'),'string','Log Likelihood','fontsize',16);
set(gca,'Xdir','reverse','Ydir','reverse');
xlabel('Time (Ma)','fontsize',16); ylabel('Temperature (^{\circ}C)','fontsize',16);
plot(t, pchip(t_nodes,best_T,t), 'k','LineWidth',2); box on; grid on;

hold off
disp('Plotting the predicted and observed data ...');
% fig 3: U-Pb age profiles against data
plotoutput(t_nodes,best_T,kineticsfiles,profilefiles,num_GridNodes);

end