function [Conc206_node,Conc206_node_t] = Function_UPbDiff(t_nodes,T_nodes,SampleData,GridNode,eff238Conc)

    num_GridNodes = 512;

    %%%%% Decay constants %%%%% 
    l238 = 1.55125e-10/365.2425/24/3600;      
    l235 = 9.8485e-10/365.2425/24/3600;
    %%%%%%%%%%%%%%%%%

    %%%%% INPUT %%%%%
    Ea  = SampleData.data(9)*1000*0.239;  % convert Activation Energy to cal/mol
    Do  = SampleData.data(10);             % get values from specific location in Sample Data matrix
    dr  = SampleData.data(19);

    t_nodes = double(t_nodes*1000000*365.2425*24*3600); % convert t to seconds as double class
    T_nodes = double(T_nodes+273.15);                   % convert T to Kelvin as double class

    %%% preallocate Matrices %%%
    rhside_206 = zeros(num_GridNodes-1,1);
    bet_206    = zeros(num_GridNodes-1,1);
    gam_206    = zeros(num_GridNodes-1,1);

        u_206 = zeros(num_GridNodes,1);     % reset Pb206-concentration to 0 before starting the Accumulation/Diffusion calculation  
    for y = 1:size(t_nodes,1)-1         % Loop through time nodes
        dts = t_nodes(y)-t_nodes(y+1);  % calculate delta-t in secs
        Dt  = Do*exp(-Ea/1.9859/((T_nodes(y)+T_nodes(y+1))/2));   % calculate Diffusion coefficient with mean Temperature

        eff206Prod_node = eff238Conc(:).* (exp(l238*t_nodes(y))-exp(l238*t_nodes(y+1)));     % calculate effective Pb206-Production at each node

        %%%%% Thomas Algorithm - solving tri-dimensional matrix %%%%%
        beta_206      = (2*dr^2)/(Dt*dts);
        Term_206      = eff206Prod_node.*GridNode*beta_206;
        mainDiag2_206 = -2-beta_206;
        mainDiag1_206 = mainDiag2_206-1;
        rhside_206(1) = (2-beta_206+1)*u_206(1)-u_206(2)-Term_206(1);
        bet_206(1)    = 1/mainDiag1_206;
        gam_206(1)    = rhside_206(1)/mainDiag1_206;

        for z = 2:num_GridNodes-1       % loop through Grid Nodes  
            rhside_206(z) = -u_206(z-1) + (2-beta_206)*u_206(z) - u_206(z+1) - Term_206(z);
            bet_206(z)    = 1/(mainDiag2_206-bet_206(z-1));
            gam_206(z)    = (rhside_206(z)-gam_206(z-1))/(mainDiag2_206-bet_206(z-1));

        end

        for z = num_GridNodes-1:-1:1   % back-substitution, loop from Grid Node(end-1) to Grid Node(1) 
            u_206(z) = gam_206(z) - bet_206(z)*u_206(z+1);
        end
        u_206_y(:,y) = u_206;   % save u for each time step

        Conc206_node_t(:,y) = u_206./GridNode(:);

    end

    %% calculate Pb206-Concentration at each Grid Node at each time step
    %Conc206_node_y  = bsxfun(@rdivide,u_206_y,GridNode(:));
    % Conc206_trpz_y  = (Conc206_node_y(1:end-1,:) + Conc206_node_y(2:end,:))*dr/2;
    % Conc206_y       = sum(bsxfun(@times,Conc206_trpz_y,V_subShell(:)));

    Conc206_node  = u_206./GridNode(:);
    % calculate Pb206-Concentration at each Grid Node
    % Conc206_trpz  = (Conc206_node(1:end-1) + Conc206_node(2:end))*dr/2;
    % Conc206       = sum(Conc206_trpz.* V_subShell(:));

end