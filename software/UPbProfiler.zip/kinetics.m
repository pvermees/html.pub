function [SampleData,GridNode,eff238Conc,r_sphere] = kinetics(kineticsfile,num_GridNodes)  

    Import_Kinetics = importdata(kineticsfile);  % Import kinetic data
    SampleData(:,:) = Import_Kinetics;

    Geometry      = SampleData.data(1);                  % get values from specific location in Mineral Data matrix
            L             = SampleData.data(2)/10000;    % and convert to cm's
            W             = SampleData.data(3)/10000;
            H             = SampleData.data(4)/10000;
            T             = SampleData.data(5)/10000;
            r             = SampleData.data(6)/10000;
            Density       = SampleData.data(7);
            cU238         = SampleData.data(11);

    %%%%%%%%%%%%%%%%% Equivalent Sphere Radius Calculation %%%%%%%%%%%%%%%%%%%%%%%%%%

            if L*10000 ~= -1 || r*10000 == -1   % use Length and Width for calculations
                switch Geometry
                    case 1 % Spherical Grain
                            r_sphere = (L+W)/2/2;
                            mass     = 4/3*r_sphere^3*pi*Density;
                    case 2 % Elliptical Grain
                            p        = 1.6075;  % parameter p for Ellipsoid Surface calculation
                            Surface  = 4*pi*((H^p*W^p + H^p*L^p + W^p*L^p)/3)^(1/p);
                            Volume   = 4/3*H*W*L*pi;
                            SV_ratio = Surface/Volume;
                            r_sphere = 3/SV_ratio;
                            mass     = Volume*Density;
                    case 3 % Cylindrical Grain
                            Surface  = 2*pi*(W/2)*(W+L);
                            Volume   = (W/2)^2*pi*L;
                            SV_ratio = Surface/Volume;
                            r_sphere = 3/SV_ratio;
                            mass     = Volume*Density;
                    case 4 % Tetragonal prismatic Grain
                            switch T == 0
                                case 1
                                    Surface_B = 2*(W*L) + 2*(H*L) + 2*(H*W);
                                    Volume_B  = H*W*L;
                                    SV_ratio  = Surface_B/Volume_B;
                                    mass = Volume_B*Density;
                                case 0
                                    Surface_B = 2*(W*(L-2*T))+2*(H*(L-2*T));   % no basal planes for Surface area, Tip height substracted from overall Length!!!
                                    Volume_B  = H*W*(L-2*T);
                                    SL_W      = sqrt((H/2)^2 + T^2);     % calculate Side Length for Pyramid face (Base = width)
                                    SL_H      = sqrt((W/2)^2 + T^2);     % calculate Side Length for Pyramid face (Base = height)
                                    Surface_T = 2*(W*SL_W/2 + H*SL_H/2);   % add 2 pairs of Pyramid surfaces  
                                    Volume_T  = 1/3*H*W*T;
                                    SV_ratio  = (2*Surface_T + Surface_B)/(2*Volume_T + Volume_B);
                                    mass  = (Volume_B + 2*Volume_T)*Density;
                            end
                            r_sphere = 3/SV_ratio;

                    case 5 % Hexagonal prismatic Grain
                            Surface  = 2*(3/2*sqrt(3)*(W/2)^2)+6*(W/2*L);
                            Volume   = 3/2*sqrt(3)*(W/2)^2*L; 
                            SV_ratio = Surface/Volume;
                            r_sphere = 3/SV_ratio;
                            mass     = Volume*Density;
                end    
            else                                % use predefined spherical radius for calculations
               r_sphere = r;
               mass     = 4/3*r_sphere^3*pi*Density;           
            end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%% GRID SETUP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    dr              = 2*r_sphere/(2*num_GridNodes-1);  % calculate spacing between the Grid Nodes (delta r, Ketcham 2005,p.295)
    GridNodes       = (1:num_GridNodes)';
    GridNode        = dr*GridNodes-dr*0.5;      % defines radial position (cm's from center) of Grid Nodes

    %%%%%%%%%%%%%%%%%%%%%% EFFECTIVE CONCENTRATION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
    eff238Conc = single(1:num_GridNodes);
    eff238Conc(:) = cU238;    % calculate effective U238 Concentration at each node

    SampleData.data(6)  = r_sphere*10000;  % update Sample Data after equivalent sphere calcs
    SampleData.data(8)  = mass;
    SampleData.data(19) = dr;

end