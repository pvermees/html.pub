% Plot radial age profile
function plotoutput(t_nodes,T_nodes,kineticsfiles,profilefiles,num_GridNodes)
    lyr238 = 1.55125e-10;
    nd = length(kineticsfiles); % number of datasets
    np = ceil(sqrt(nd)); % number of plots
    for i = 1:nd,
        [SampleData{i},GridNode{i},eff238Conc{i},r_sphere{i}] = kinetics(kineticsfiles{i},num_GridNodes);
        [depth{i},mu{i},sigma{i}] = profile(profilefiles{i});
    end
    [t,T] = interpolate(t_nodes,T_nodes,32);
    figure
    for i = 1:nd,
        Conc206_node = Function_UPbDiff(t,T,SampleData{i},GridNode{i},eff238Conc{i});
        Conc206_node_all(:,1) = single(Conc206_node);
        Age206_node_all(:,1)  = log((Conc206_node_all(:,1)./eff238Conc{i}(:))+1)/lyr238;
        rx = linspace(0,r_sphere{i}*10000,num_GridNodes); % radial distance in microns
        ry = Age206_node_all/1000000; % modelled ages
        subplot(np,np,i)
        plot(rx,ry,'-b'); hold on;
        errorbar(r_sphere{i}*10000-depth{i},mu{i},2*sigma{i},'.k');
        xlabel('radial distance'); ylabel('age'); title(profilefiles{i});
    end
    %figure;
    %plot(t,T); xlabel('time'); ylabel('Temperature')
end