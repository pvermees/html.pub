function [depth,mu,sigma] = profile(datafile)

    profiledat = importdata(datafile);
    depth = profiledat(:,1);
    mu = profiledat(:,2);
    sigma = profiledat(:,3)/2;

end