niter = 20000; % number of iterations
n_nodes = 5; % number of t-T nodes
max_T = 825; % maximum temperature considered
monotonic = true; % only consider monotonic t-T histories?
burnin = 20; % discard the first 20% of the results
kineticsfiles = {'data/kineticsJM119C-10.xls';...
                 'data/kineticsJM119C-32.xls';...
                 'data/kineticsJM119C-42.xls'};
profilefiles = {'data/profileJM119C-10.txt';...
                'data/profileJM119C-32.txt';...
                'data/profileJM119C-42.txt'};

num_GridNodes = 512;

[LL,t_nodes,T_nodes] = invert(niter,n_nodes,kineticsfiles,profilefiles,...
                              num_GridNodes,max_T,monotonic);

plotter(LL,t_nodes,T_nodes,burnin,kineticsfiles,profilefiles,num_GridNodes);