function varargout = mudisc(varargin)
% MUDISC M-file for mudisc.fig
% Last Modified by GUIDE v2.5 01-Apr-2014 11:48:23

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @mudisc_OpeningFcn, ...
                   'gui_OutputFcn',  @mudisc_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before mudisc is made visible.
function mudisc_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to mudisc (see VARARGIN)

% Choose default command line output for mudisc
handles.output = hObject;
% Initialise default MDS settings
handles.doQQ = true;
handles.doMDS = true;
handles.doShepard = true;
handles.dometric = false;
handles.dolines = false;
set(handles.QQcheckbox,'Value',handles.doQQ);
set(handles.MDSbox,'Value',handles.doMDS);
set(handles.shepardbox,'Value',handles.doShepard);
set(handles.metricbox,'Value',handles.dometric);
set(handles.linesbox,'Value',handles.dolines);

% Update handles structure
guidata(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = mudisc_OutputFcn(hObject, eventdata, handles)
% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes during object creation, after setting all properties.
function filenamebox_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in selectbutton.
function selectbutton_Callback(hObject, eventdata, handles)
[filename,pathname,filterindex] = uigetfile('*.xls','Pick and Excel file');
if (filterindex)
    handles.filename = strcat(pathname,filename);
end
set(handles.filenamebox,'String',handles.filename);
guidata(hObject, handles);
drawnow;

% --- Executes on button press in exitbutton.
function exitbutton_Callback(hObject, eventdata, handles)
clear all; close all;

% --- Executes on button press in plotbutton.
function plotbutton_Callback(hObject, eventdata, handles)
mds(handles);

% --- Executes on button press in QQcheckbox.
function QQcheckbox_Callback(hObject, eventdata, handles)
handles.doQQ = get(hObject,'Value');
guidata(hObject, handles);

% --- Executes on button press in MDSbox.
function MDSbox_Callback(hObject, eventdata, handles)
handles.doMDS = get(hObject,'Value');
guidata(hObject, handles);

% --- Executes on button press in shepardbox.
function shepardbox_Callback(hObject, eventdata, handles)
handles.doShepard = get(hObject,'Value');
guidata(hObject, handles);

% --- Executes on button press in metricbox.
function metricbox_Callback(hObject, eventdata, handles)
handles.dometric = get(hObject,'Value');
guidata(hObject, handles);

% --- Executes on button press in linesbox.
function linesbox_Callback(hObject, eventdata, handles)
handles.dolines = get(hObject,'Value');
guidata(hObject, handles);

% --- This function does all the actual work.
function mds(handles)
try
    close 'QQ-plot' 'MDS map' 'Shepard plot'
catch err
    % no plots open yet (error)
end
% don't flag the error which you get when Excel is not installed on your system
warning('off','MATLAB:xlsread:ActiveX');
[numeric,txt,raw] = xlsread(handles.filename);
names = txt;
n = length(txt);
data = cell(1,n);
for i=1:n,
    col = numeric(:,i);
    data{i} = col(isfinite(col));
end
MIN = inf; MAX = -inf;
% calculate the dissimilarity matrix:
diss = zeros(n);
for i=1:n,
    if (min(data{i})<MIN) MIN = min(data{i}); 
    end
    if max(data{i})>MAX
        MAX = max(data{i}); 
    end
    for j=1:n,
        [h,p,s] = kstest2(data{i},data{j});
        diss(i,j) = s;
    end
end

% Q-Q plots
if (handles.doQQ)
    percentiles = (0:5:100);
    p = zeros(n,length(percentiles));
    for i=1:n,
        p(i,:) = prctile(data{i},percentiles);
    end
    figure('Name','QQ-plot','NumberTitle','off');
    for i=1:n,
        for j=1:n,
            if (i>j)
                axes('position',[(i-1)/(n+1),1-(j+1)/(n+1),1/(n+1),1/(n+1)]);
                plot(p(i,:),p(j,:),'.b',[MIN,MAX],[MIN,MAX],'-k');
                box on; axis tight; set(gca,'XTick',[],'YTick',[]);
            end
            if (i==2)
                ylabel(names{1});
            end
            if (i==j+1)
                xlabel(names{i});
            end
        end
    end
    axes('position',[2/(n+1),2/(n+1),3/(n+1),3/(n+1)]);
    plot([MIN,MAX],[MIN,MAX],'-k'); text(MIN/2+MAX/2,MIN/2+MAX/2,'1:1');
    box on; axis tight; xlabel('Age (Ma)'); ylabel('Age (Ma)');
end

% plot MDS map
if (handles.dometric)
    [XY,stress,disparities] = mdscale(diss,2,'Criterion','metricstress');
else
    [XY,stress,disparities] = mdscale(diss,2,'Criterion','stress');
end
X = XY(:,1); Y = XY(:,2);
if (handles.doMDS)
    Xrange = max(X)-min(X);
    Yrange = max(Y)-min(Y);
    buffer = 0.1;
    minX = min(X)-Xrange*buffer;
    maxX = max(X)+Xrange*buffer;
    minY = min(Y)-Yrange*buffer;
    maxY = max(Y)+Yrange*buffer;
    figure('Name','MDS map','NumberTitle','off');
    set(gca,'FontUnits','normalized');
    fsize = get(gca,'FontSize')/4;
    set(gca,'FontUnits','points');    
    plot(X,Y,'.k'); hold on; box on; xlim([minX,maxX]); ylim([minY,maxY]); axis equal;
    text(X+fsize,Y,names,'Color','r');
    if (handles.dolines) % plot nearest neighbour lines
        [foo,i] = sort(diss,1,'ascend');
        first = i(2,:);
        second = i(3,:);
        plot([X X(first)]',[Y Y(first)]','-k',[X X(second)]',[Y Y(second)]',':k');
    end
end

% generate Shepard plot
if (handles.doShepard)
    figure('Name','Shepard plot','NumberTitle','off'); hold on;
    distances = pdist(XY);
    [foo,ord] = sortrows([disparities(:) diss(:)]);
    x = nonzeros(triu(diss)');
    y = distances';
    %z = 5+rand(size(y))*2.5;
    %for i=1:length(distances),
    %    plot(x(i), y(i),'ob','MarkerSize',z(i));
    %end
    plot(x, y,'ob');
    plot(diss(ord),disparities(ord),'r.-');
    xlabel('Dissimilarities'); ylabel('Distances/Disparities')
    legend({'Distances' 'Dissimilarities'}, 'Location','NorthWest');
    title(strcat('Stress = ',num2str(stress)));
end