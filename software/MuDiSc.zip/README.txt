Follow the following steps to run MuDiSc:

1. Download mudisc.m and mudisc.fig into the same directory

2. Start Matlab

3. Type 'mudisc' (without the quotes) at the command prompt
