setwd('/home/pvermees/Dropbox/talks/R')
library(IsoplotR)

# Rb-Sr isochron:
RbSr <- read.data('RbSr1.csv',method='Rb-Sr',format=1)  
isochron(RbSr)  
# Weighted mean plot:
meandat <- read.data('LudwigMean.csv',method='other')  
weightedmean(meandat)  
# 40Ar/39Ar release spectrum:
ArAr <- read.data('ArAr3.csv',method='Ar-Ar',format=3)  
agespectrum(ArAr,random.effects = FALSE)  
# U/Pb ages:
UPb <- read.data('UPb2.csv',method='U-Pb',format=2)  
tt <- age(UPb)
write.csv(tt,file='UPbAges.csv',row.names=FALSE)

# Plot the concordia line:
tt <- seq(from=0,to=4000,by=10)
lam235 <- 0.00098485
lam238 <- 0.000155125
Pb207U235 <- exp(lam235*tt) - 1
Pb206U238 <- exp(lam238*tt) - 1
plot(x=Pb207U235,y=Pb206U238,type='l')
# annotate:
tlab <- seq(from=0,to=4000,by=1000)
ti <- which(tt %in% tlab)
points(x=Pb207U235[ti],y=Pb206U238[ti])
text(x=Pb207U235[ti],y=Pb206U238[ti],labels=tlab,pos=2)

# alternatively, using IsoplotR:
concordia(tlim=c(0,4000))

concordia(tlim=c(100,4000),wetherill=FALSE)

Luozi <- read.data('Luozi.csv',method='U-Pb',format=3)
concordia(Luozi,wetherill=TRUE)
concordia(Luozi,wetherill=FALSE)

concordia(examples$UPb)

concordia(examples$UPb,hide=10)

concordia(examples$UPb,hide=10,show.age=1)

ns <- 10
X <- rnorm(ns,mean=10,sd=2)
err <- rep(2,ns)
weightedmean(cbind(X,err),detect.outliers=FALSE)

concordia(examples$UPb,hide=10,show.age=1,exterr=TRUE)

UPb <- read.data('diseq.csv',method='U-Pb',format=2,U48=0,Th0U8=2,Ra6U8=2,Pa1U5=2)
concordia(UPb,wetherill=FALSE,xlim=c(-500,5000),ylim=c(0.047,0.056),
          ticks=c(1,2,3,5,10,50,100,200,300),show.age=1)

UPb <- read.data('Hourigan.csv',method='U-Pb',format=2)
concordia(UPb)

Hourigan <- read.csv('Hourigan.csv',header=TRUE)
UPb <- read.data(Hourigan[,1:5],method='U-Pb',format=2)
concordia(UPb,levels=Hourigan[,'ThU'],clabel='Th/U',show.age=2)

UPb <- read.data('McClure.csv',method='U-Pb',format=5,ierr=3)
concordia(UPb,wetherill=FALSE)

settings('iratio','Pb207Pb204',15.42,0.17)
settings('iratio','Pb206Pb204',17.38,0.17)
concordia(UPb,wetherill=FALSE,common.Pb=3)

concordia(UPb,wetherill=FALSE,common.Pb=2,show.age=2)

concordia(UPb,wetherill=FALSE,common.Pb=1)

UPb <- read.data('CN2000.csv',method='U-Pb',format=5,ierr=1)
concordia(UPb,common.Pb=0)

UPb <- read.data('BH14.csv',method='U-Pb',format=2,ierr=3)
concordia(UPb,wetherill=FALSE,show.age=2,xlim=c(-5,115),ylim=c(0,0.8))

concordia(UPb,wetherill=FALSE,show.age=2,xlim=c(-5,115),ylim=c(0,0.8),common.Pb=2)

concordia(UPb,wetherill=FALSE,show.age=3,xlim=c(-5,115),ylim=c(0,0.8))

concordia(UPb,wetherill=FALSE,show.age=4,xlim=c(-5,115),ylim=c(0,0.8))

Luozi <- read.data('Luozi.csv',method='U-Pb',format=3)
kde(Luozi,common.Pb=1,bw=250,binwidth=500)
kde(Luozi,common.Pb=1,type=5)
cad(Luozi,common.Pb=1,type=5)

Ecuador <- read.data('M12.csv',method='U-Pb',format=3)
concordia(Ecuador,wetherill=FALSE,show.age=2,common.Pb=2)

radialplot(Ecuador,common.Pb=2,k='min',show.numbers=TRUE)

Luozi <- read.data('Luozi.csv',method='U-Pb',format=3)
radialplot(Luozi,common.Pb=1,k='min')

MuUs <- read.data('MuUs.csv',method='detritals')
names(MuUs)[1:10] <- 1:10
mds(MuUs)
mds(MuUs,shepard=TRUE)

library(provenance)

DZ <- read.distributional("DZ.csv")
HM <- read.counts("HM.csv")
PT <- read.counts("PT.csv")
Major <- read.compositional("Major.csv",col='cm.colors')
Trace <- read.compositional("Trace.csv",col='cm.colors')
summaryplot(KDEs(DZ),HM,PT,Major,Trace)

plot(MDS(DZ))
plot(MDS(HM))
plot(MDS(PT))
plot(MDS(Major))
plot(MDS(Trace))

plot(procrustes(DZ,HM,PT,Major,Trace))
plot(indscal(DZ,HM,PT,Major,Trace))
