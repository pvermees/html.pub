library(provenance)

XRF <- read.compositional('XRF.csv')

plot(PCA(XRF))